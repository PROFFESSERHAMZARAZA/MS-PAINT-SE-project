# 🎨 MS Paint Clone — Software Engineering Project (SRS)

A Software Requirements Specification (SRS) for a **Java Swing-based MS Paint Clone**, developed as a semester project for the **Software Engineering** course at **Air University, Kamra Campus**.

This repository documents the complete software design lifecycle for a desktop raster-graphics drawing application — from requirements gathering to UML modeling and test case design — demonstrating core Object-Oriented Programming (OOP) principles.

---

## 📋 Project Overview

The **MS Paint Clone** is a standalone Java desktop application that lets users:

- ✏️ Draw freehand using a **Pen tool**
- 🧽 Erase drawings with an **Eraser tool**
- 📏 Draw straight lines with a **Line tool**
- 🎨 Pick any color via a **Color Picker**
- 🖌️ Adjust **brush size** (1–50 px)
- ↩️ **Undo / Redo** stroke history (dual-stack pattern)
- 💾 **Save** the canvas as a PNG image
- ❌ **Exit** with a confirmation dialog

Built entirely with the standard **Java Swing** and **Java2D** libraries — no external dependencies.

---

## 📁 Repository Structure

```
MS-Paint-Clone-SE-Project/
├── README.md
└── docs/
    └── SE_PROJECT_SRS.pdf   # Full Software Requirements Specification
```

---

## 📖 What's Inside the SRS Document

| Section | Contents |
|---|---|
| 1. Introduction | Purpose, scope, and intended audience |
| 2. Overall Description | Product perspective, features, user classes, operating environment |
| 3. Functional Requirements | FR-1 to FR-10 (all tools & actions) |
| 4. Non-Functional Requirements | Performance, Portability, Usability, Reliability |
| 5. OOP Design | Architecture, Use Case, Class, Sequence, Activity & State Diagrams (UML) |
| 6. User Interface Design | UI wireframe and layout decisions |
| 7. Testing Requirements | 15 test cases (TC-01 to TC-15) + sample Java test implementations |
| 8. Conclusion | OOP principles applied and future enhancements |

---

## 🧠 OOP Principles Demonstrated

- **Encapsulation** — `PaintCanvas` bundles drawing state with the behavior that manipulates it
- **Abstraction** — `Tool` enum and `Stroke` inner class hide implementation details
- **Inheritance** — `PaintFrame extends JFrame`, `PaintCanvas extends JPanel`
- **Polymorphism** — `MouseListener` / `MouseMotionListener` behavior varies per active tool

---

## 👥 Team

| Name | Student ID |
|---|---|
| Zaid Ahmad | 2520147 |
| Muhammad Hamza | 2520207 |
| Umais Ali Shah | 245432 |

**Submitted to:** Miss Aqsa Hameed
**Course:** Software Engineering
**Institution:** Air University, Kamra Campus

---

## 🚀 Future Enhancements

- Scrollable / zoomable canvas
- Text insertion tool
- Shape-fill primitives
- Multi-layer support
- Keyboard shortcuts
- File-format selection at save time
- Persistent undo history (serialized to disk)

---

## 📄 License

This project was created for academic purposes as part of a university course.
